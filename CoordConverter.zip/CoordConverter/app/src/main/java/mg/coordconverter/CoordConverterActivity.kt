package mg.coordconverter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import mg.coordconverter.databinding.ActivityCoordBinding

class CoordConverterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCoordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCoordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.fromSysGroup.setOnCheckedChangeListener { _, checkedId ->
            val isUtm = checkedId == binding.fromUtmRadio.id
            binding.fromUtmFields.visibility = if (isUtm) android.view.View.VISIBLE else android.view.View.GONE
            binding.fromWgsFields.visibility = if (isUtm) android.view.View.GONE else android.view.View.VISIBLE
        }

        binding.toSysGroup.setOnCheckedChangeListener { _, checkedId ->
            binding.toUtmFields.visibility =
                if (checkedId == binding.toUtmRadio.id) android.view.View.VISIBLE else android.view.View.GONE
        }

        binding.convertButton.setOnClickListener { convert() }
    }

    private fun convert() {
        try {
            // 1. Mamaky ny coordonnée miditra, avadika ho lat/lon WGS84 aloha (pivot)
            val lat: Double
            val lon: Double

            if (binding.fromSysGroup.checkedRadioButtonId == binding.fromUtmRadio.id) {
                val zone = binding.fromZone.text.toString().toIntOrNull()
                    ?: throw IllegalArgumentException("Fenoy ny zone UTM.")
                val x = binding.fromX.text.toString().toDoubleOrNull()
                    ?: throw IllegalArgumentException("Fenoy ny X.")
                val y = binding.fromY.text.toString().toDoubleOrNull()
                    ?: throw IllegalArgumentException("Fenoy ny Y.")
                val south = binding.fromHemisS.isChecked

                val ll = UtmConverter.utmToLatLon(zone, south, x, y)
                lat = ll.lat
                lon = ll.lon
            } else {
                lat = binding.fromLat.text.toString().toDoubleOrNull()
                    ?: throw IllegalArgumentException("Fenoy ny latitude.")
                lon = binding.fromLon.text.toString().toDoubleOrNull()
                    ?: throw IllegalArgumentException("Fenoy ny longitude.")
            }

            // 2. Mamoaka amin'ny système alaina
            val result = StringBuilder()

            when (binding.toSysGroup.checkedRadioButtonId) {
                binding.toWgsRadio.id -> {
                    result.append("Latitude: %.6f\n".format(lat))
                    result.append("Longitude: %.6f".format(lon))
                }
                binding.toUtmRadio.id -> {
                    val zone = binding.toZone.text.toString().toIntOrNull()
                        ?: throw IllegalArgumentException("Fenoy ny zone alaina.")
                    val south = binding.toHemisS.isChecked
                    val utm = UtmConverter.latLonToUtm(lat, lon, zone, south)
                    result.append("UTM zone $zone${if (south) "S" else "N"}\n")
                    result.append("X (Easting): %.2f m\n".format(utm.x))
                    result.append("Y (Northing): %.2f m".format(utm.y))
                }
                else -> {
                    val xy = UtmConverter.latLonToWebMercator(lat, lon)
                    result.append("Web Mercator X: %.2f m\n".format(xy.x))
                    result.append("Web Mercator Y: %.2f m".format(xy.y))
                }
            }

            binding.resultText.text = result.toString()
        } catch (e: Exception) {
            binding.resultText.text = "Diso: ${e.message ?: "Jereo indray ny isa nosoratana."}"
        }
    }
}
