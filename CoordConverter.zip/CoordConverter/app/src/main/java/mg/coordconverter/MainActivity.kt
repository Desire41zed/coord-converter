package mg.coordconverter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import mg.coordconverter.databinding.ActivityLauncherBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLauncherBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.openCoordConverter.setOnClickListener {
            startActivity(Intent(this, CoordConverterActivity::class.java))
        }

        binding.openParcel.setOnClickListener {
            startActivity(Intent(this, ParcelActivity::class.java))
        }
    }
}
