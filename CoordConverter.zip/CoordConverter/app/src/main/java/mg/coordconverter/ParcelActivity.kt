package mg.coordconverter

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import mg.coordconverter.databinding.ActivityParcelBinding
import java.io.BufferedReader
import java.io.InputStreamReader

class ParcelActivity : AppCompatActivity() {

    private lateinit var binding: ActivityParcelBinding
    private lateinit var adapter: PointsAdapter
    private val points = mutableListOf<ParcelPoint>()

    private val openCsvLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) importCsv(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityParcelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = PointsAdapter { position ->
            points.removeAt(position)
            refresh()
        }
        binding.pointsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.pointsRecyclerView.adapter = adapter

        binding.addPointButton.setOnClickListener {
            val x = binding.inputX.text.toString().toDoubleOrNull()
            val y = binding.inputY.text.toString().toDoubleOrNull()
            if (x == null || y == null) {
                binding.surfaceResult.text = "Diso: fenoy tsara ny X sy Y (isa)."
                return@setOnClickListener
            }
            points.add(ParcelPoint(label = "P${points.size + 1}", x = x, y = y))
            binding.inputX.text.clear()
            binding.inputY.text.clear()
            refresh()
        }

        binding.importCsvButton.setOnClickListener {
            openCsvLauncher.launch(arrayOf("text/*", "text/comma-separated-values", "text/csv"))
        }

        refresh()
    }

    private fun importCsv(uri: Uri) {
        try {
            val added = mutableListOf<ParcelPoint>()
            contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream)).forEachLine { rawLine ->
                    val line = rawLine.trim()
                    if (line.isEmpty()) return@forEachLine

                    val parts = line.split(",", ";", "\t").map { it.trim() }
                    if (parts.size < 2) return@forEachLine

                    val x = parts[0].toDoubleOrNull()
                    val y = parts[1].toDoubleOrNull()
                    if (x != null && y != null) {
                        val label = if (parts.size >= 3 && parts[2].isNotBlank()) parts[2] else "P${points.size + added.size + 1}"
                        added.add(ParcelPoint(label = label, x = x, y = y))
                    }
                    // Raha tsy azo novaina ho isa ny X/Y (ohatra andalana "en-tête" hoe X,Y), dia atsipy tsotra izany.
                }
            }

            if (added.isEmpty()) {
                binding.surfaceResult.text = "Diso: tsy nahitana point ao anaty fichier. Mila endrika \"X,Y\" isaky ny andalana."
                return
            }

            points.addAll(added)
            refresh()
        } catch (e: Exception) {
            binding.surfaceResult.text = "Diso: tsy voavaky ny fichier (${e.message ?: "hadisoana tsy fantatra"})."
        }
    }

    private fun refresh() {
        adapter.submitList(points)
        binding.polygonView.setPoints(points)

        if (points.size < 3) {
            binding.surfaceResult.text = "Surface: mila point 3 farafahakeliny (efa misy ${points.size})."
            return
        }

        val areaM2 = PolygonMath.areaM2(points)
        val areaHa = areaM2 / 10000.0
        binding.surfaceResult.text = "Surface: %.2f m²  (%.4f ha)".format(areaM2, areaHa)
    }
}
