# Mpanova Coordonnée — App Android

Application Android fanovana coordonnée (UTM ↔ WGS84 lat/lon ↔ Web Mercator).

## Ahoana ny fomba hamoahana ny fichier .apk

1. **Alaina** ny [Android Studio](https://developer.android.com/studio) (maimaimpoana) raha mbola tsy manana.
2. Sokafy Android Studio → **Open** → tondroy ity dossier `CoordConverter` ity manontolo.
3. Andraso ny **Gradle sync** hifarana (mety maka minitra vitsivitsy, mila internet ny fanaovana azy voalohany satria maka ireo "dependencies").
4. Rehefa vita ny sync, tsindrio ny menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Rehefa vita ny build, dia hisy hoe "locate" eo ambany — tsindrio izany hahitanao ny fichier:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Io `app-debug.apk` io no fichier azonao **alefa mivantana any amin'ny téléphone Android** (na alefa amin'ny USB, na Bluetooth, na Google Drive) mba hampiharina.

## Ny votoatiny

- `app/src/main/java/mg/coordconverter/UtmConverter.kt` — ny formule matematika fanovana UTM ↔ WGS84 ↔ Web Mercator
- `app/src/main/java/mg/coordconverter/MainActivity.kt` — ny lojika mampikambana ny écran amin'ny fanovana
- `app/src/main/res/layout/activity_main.xml` — ny endriky ny écran (formulaire)

## Raha tianao hampiana système hafa (ohatra Laborde Madagascar)

Ny formule ao amin'ny `UtmConverter.kt` dia mandeha amin'ny ellipsoïde WGS84 fotsiny (UTM sy Web Mercator). Raha ilainao ny système **Laborde** (izay be mpampiasa amin'ny cadastre eto Madagasikara), dia mila ampiana formule hafa io — azafady lazao ahy raha ilainao izany, fa fanamboarana manokana no takiana.
