package mg.coordconverter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PointsAdapter(
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PointsAdapter.ViewHolder>() {

    private val items = mutableListOf<ParcelPoint>()

    fun submitList(newItems: List<ParcelPoint>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.pointLabel)
        val xVal: TextView = view.findViewById(R.id.pointX)
        val yVal: TextView = view.findViewById(R.id.pointY)
        val deleteBtn: TextView = view.findViewById(R.id.pointDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_point, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.label.text = item.label.ifBlank { "P${position + 1}" }
        holder.xVal.text = "X: %.3f".format(item.x)
        holder.yVal.text = "Y: %.3f".format(item.y)
        holder.deleteBtn.setOnClickListener { onDelete(position) }
    }

    override fun getItemCount() = items.size
}
