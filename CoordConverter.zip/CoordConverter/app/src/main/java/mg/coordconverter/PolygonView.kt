package mg.coordconverter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

data class ParcelPoint(val label: String, val x: Double, val y: Double)

/** Fikajiana Surface amin'ny formule "shoelace" (mikatona ho polygone ny farany-voalohany). */
object PolygonMath {
    fun areaM2(points: List<ParcelPoint>): Double {
        if (points.size < 3) return 0.0
        var sum = 0.0
        val n = points.size
        for (i in 0 until n) {
            val a = points[i]
            val b = points[(i + 1) % n]
            sum += a.x * b.y - b.x * a.y
        }
        return abs(sum) / 2.0
    }
}

/** Canvas kely mampiseho ny point sy ny polyligne mifanaraka amin'ny coordonnée X,Y (mitovy endrika AutoCAD). */
class PolygonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: List<ParcelPoint> = emptyList()

    private val linePaint = Paint().apply {
        color = Color.parseColor("#4FB3A3")
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val fillPaint = Paint().apply {
        color = Color.parseColor("#334FB3A3")
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val pointPaint = Paint().apply {
        color = Color.parseColor("#D7A24C")
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val textPaint = Paint().apply {
        color = Color.parseColor("#EEF2F0")
        textSize = 26f
        isAntiAlias = true
    }
    private val emptyPaint = Paint().apply {
        color = Color.parseColor("#5C6B67")
        textSize = 30f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    fun setPoints(newPoints: List<ParcelPoint>) {
        points = newPoints
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (points.size < 2) {
            canvas.drawText(
                "Ampio point roa farafahakeliny mba hahita sary",
                width / 2f, height / 2f, emptyPaint
            )
            return
        }

        val padding = 40f
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }

        val spanX = (maxX - minX).takeIf { it > 0.0001 } ?: 1.0
        val spanY = (maxY - minY).takeIf { it > 0.0001 } ?: 1.0

        val scaleX = (width - 2 * padding) / spanX
        val scaleY = (height - 2 * padding) / spanY
        val scale = minOf(scaleX, scaleY)

        // Miova ho koordinato écran: X mitovy hevitra, Y ampiovaina (Y ambony amin'ny map = ambony amin'ny écran)
        fun toScreenX(x: Double) = (padding + (x - minX) * scale).toFloat()
        fun toScreenY(y: Double) = (height - padding - (y - minY) * scale).toFloat()

        val path = Path()
        points.forEachIndexed { i, p ->
            val sx = toScreenX(p.x)
            val sy = toScreenY(p.y)
            if (i == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        if (points.size >= 3) {
            path.close()
            canvas.drawPath(path, fillPaint)
        }
        canvas.drawPath(path, linePaint)

        points.forEachIndexed { i, p ->
            val sx = toScreenX(p.x)
            val sy = toScreenY(p.y)
            canvas.drawCircle(sx, sy, 10f, pointPaint)
            canvas.drawText(p.label.ifBlank { (i + 1).toString() }, sx + 14f, sy - 14f, textPaint)
        }
    }
}
