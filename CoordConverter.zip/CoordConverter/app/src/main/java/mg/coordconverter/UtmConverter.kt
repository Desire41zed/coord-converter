package mg.coordconverter

import kotlin.math.*

/**
 * Fanovana coordonnée UTM <-> WGS84 (lat/lon), ary WGS84 -> Web Mercator.
 * Mampiasa ny ellipsoïde WGS84 (a = 6378137 m, f = 1/298.257223563).
 */
object UtmConverter {

    private const val A = 6378137.0
    private const val F = 1.0 / 298.257223563
    private const val K0 = 0.9996
    private val E = sqrt(F * (2 - F))
    private val E2 = E * E
    private val E4 = E2 * E2
    private val E6 = E4 * E2
    private val EP2 = E2 / (1 - E2)

    data class LatLon(val lat: Double, val lon: Double)
    data class UtmPoint(val x: Double, val y: Double)
    data class XY(val x: Double, val y: Double)

    /** UTM (zone, hemisphère 'N'/'S', x, y) -> latitude/longitude WGS84 (degré). */
    fun utmToLatLon(zone: Int, hemisphereSouth: Boolean, x: Double, y: Double): LatLon {
        val xAdj = x - 500000.0
        val yAdj = if (hemisphereSouth) y - 10000000.0 else y

        val m = yAdj / K0
        val mu = m / (A * (1 - E2 / 4 - 3 * E4 / 64 - 5 * E6 / 256))

        val e1 = (1 - sqrt(1 - E2)) / (1 + sqrt(1 - E2))

        val j1 = 3 * e1 / 2 - 27 * e1.pow(3) / 32
        val j2 = 21 * e1.pow(2) / 16 - 55 * e1.pow(4) / 32
        val j3 = 151 * e1.pow(3) / 96
        val j4 = 1097 * e1.pow(4) / 512

        val fp = mu + j1 * sin(2 * mu) + j2 * sin(4 * mu) + j3 * sin(6 * mu) + j4 * sin(8 * mu)

        val c1 = EP2 * cos(fp).pow(2)
        val t1 = tan(fp).pow(2)
        val n1 = A / sqrt(1 - E2 * sin(fp).pow(2))
        val r1 = A * (1 - E2) / (1 - E2 * sin(fp).pow(2)).pow(1.5)
        val d = xAdj / (n1 * K0)

        val lat = fp - (n1 * tan(fp) / r1) * (
            d.pow(2) / 2 -
            (5 + 3 * t1 + 10 * c1 - 4 * c1.pow(2) - 9 * EP2) * d.pow(4) / 24 +
            (61 + 90 * t1 + 298 * c1 + 45 * t1.pow(2) - 252 * EP2 - 3 * c1.pow(2)) * d.pow(6) / 720
        )

        val lonOrigin = Math.toRadians(((zone - 1) * 6 - 180 + 3).toDouble())

        val lon = lonOrigin + (
            d -
            (1 + 2 * t1 + c1) * d.pow(3) / 6 +
            (5 - 2 * c1 + 28 * t1 - 3 * c1.pow(2) + 8 * EP2 + 24 * t1.pow(2)) * d.pow(5) / 120
        ) / cos(fp)

        return LatLon(Math.toDegrees(lat), Math.toDegrees(lon))
    }

    /** Latitude/longitude WGS84 (degré) -> UTM (zone, hemisphère 'N'/'S', x, y). */
    fun latLonToUtm(lat: Double, lon: Double, zone: Int, hemisphereSouth: Boolean): UtmPoint {
        val latRad = Math.toRadians(lat)
        val lonRad = Math.toRadians(lon)
        val lonOrigin = Math.toRadians(((zone - 1) * 6 - 180 + 3).toDouble())

        val n = A / sqrt(1 - E2 * sin(latRad).pow(2))
        val t = tan(latRad).pow(2)
        val c = EP2 * cos(latRad).pow(2)
        val aTerm = cos(latRad) * (lonRad - lonOrigin)

        val m = A * (
            (1 - E2 / 4 - 3 * E4 / 64 - 5 * E6 / 256) * latRad -
            (3 * E2 / 8 + 3 * E4 / 32 + 45 * E6 / 1024) * sin(2 * latRad) +
            (15 * E4 / 256 + 45 * E6 / 1024) * sin(4 * latRad) -
            (35 * E6 / 3072) * sin(6 * latRad)
        )

        var x = K0 * n * (
            aTerm +
            (1 - t + c) * aTerm.pow(3) / 6 +
            (5 - 18 * t + t.pow(2) + 72 * c - 58 * EP2) * aTerm.pow(5) / 120
        ) + 500000.0

        var y = K0 * (
            m + n * tan(latRad) * (
                aTerm.pow(2) / 2 +
                (5 - t + 9 * c + 4 * c.pow(2)) * aTerm.pow(4) / 24 +
                (61 - 58 * t + t.pow(2) + 600 * c - 330 * EP2) * aTerm.pow(6) / 720
            )
        )

        if (hemisphereSouth) y += 10000000.0

        return UtmPoint(x, y)
    }

    /** Latitude/longitude WGS84 (degré) -> Web Mercator EPSG:3857 (mètre). */
    fun latLonToWebMercator(lat: Double, lon: Double): XY {
        val x = lon * 20037508.34 / 180.0
        var y = ln(tan((90 + lat) * PI / 360.0)) / (PI / 180.0)
        y = y * 20037508.34 / 180.0
        return XY(x, y)
    }
}
